#include "headdev.h"

/*
 &spi4{                                                                                                                                                                              
108     pinctrl-names = "default", "sleep";
109     pinctrl-0 = <&spi4_pins_b>;
110     pinctrl-1 = <&spi4_sleep_pins_b>;     
111     cs-gpios = <&gpioe 11 0>; //片选
112     status = "okay";
113 
114     m74hc595@0{
115         compatible = "hqyj,myspi";
116         reg = <0>;
117         spi-max-frequency = <10000000>; //10Mhz
118     };
119 };


*/


u8 code[] = {
 0x3f, //0
 0x06, //1
 0x5b, //2
 0x4f, //3
 0x66, //4
 0x6d, //5
 0x7d, //6
 0x07, //7
 0x7f, //8
 0x6f, //9
 0x77, //A
 0x7c, //b
 0x39, //c
 0x5e, //d
 0x79, //e
 0x71, //f
};

u8 which[] = {
 0x1, //sg0
 0x2, //sg1
 0x4, //sg2
 0x8, //sg3
};
struct spi_device *sspi;
int set_spi(int data,int i)
{
	int a ,j;
	u8 arr[8];
	for(i=0,j=0;i<4;i++,j++,data/=10)
	{
		arr[i]= which[j];
		i++;
		a=data%10;
		arr[i]=code[a];
	}
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	spi_write(sspi,&arr[0],8);

	return 0;
}

int m74hc595_probe(struct spi_device *spi)
{
	u8 buf[2] = {0xf,0x0};
	sspi = spi;
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	spi_write(spi,buf,ARRAY_SIZE(buf));

	return 0;
}
int m74hc595_remove(struct spi_device *spi)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	return 0;
}


const struct of_device_id spi_oftable[] = {
	{.compatible = "hqyj,myspi"},
	{},
};

struct spi_driver m74hc595 ={
	.probe = m74hc595_probe,
	.remove = m74hc595_remove,
	.driver = {
		.name = "m74hc595",
		.of_match_table = spi_oftable,
	},
};


#ifndef __HEADDEV_H__
#define __HEADDEV_H__


#define GET_CMD_SIZE(cmd)  ((cmd>>16)&0x3fff)


#define GET_TMP _IOR('H',0,int) //读取温度
#define GET_HUM _IOR('H',1,int) //读取湿度
#define LED1_ON  _IOW('L',1,int) //LED亮
#define LED1_OFF  _IOW('L',0,int) //LED灭
#define LED2_ON  _IOW('E',1,int) //LED亮
#define LED2_OFF  _IOW('E',0,int) //LED灭
#define LED3_ON  _IOW('D',1,int) //LED亮
#define LED3_OFF  _IOW('D',0,int) //LED灭
#define FENG_ON  _IOW('F',1,int)
#define FENG_OFF  _IOW('F',0,int)
#define MOTU_ON  _IOW('M',1,int)
#define MOTU_OFF  _IOW('M',0,int)
#define MING_ON _IOW('G',1,int)
#define MING_OFF _IOW('G',0,int)
#define SET_T    _IOW('S',0,short)
#define GET_T    _IOR('S',0,int)
#define SPI_TMP    _IOW('s',0,int)
#define SER_TMP    _IOW('R',0,int)



#define TMP_ADDR 0xe3 //获取温度命令码

#define HUM_ADDR 0xe5 //获取湿度命令码


#endif

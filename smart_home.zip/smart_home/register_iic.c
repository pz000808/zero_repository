#include "headdev.h"

struct i2c_client *gclient;


int i2c_hum_tmp(unsigned char reg)
{
	int rec;
	unsigned char r_buf[] = {reg};
	unsigned short data;

	struct i2c_msg r_msg[] = {
		[0] = {

			.addr = gclient->addr,
			.flags = 0,
			.len = 1,
			.buf = r_buf,
		},
		[1] = {
			.addr = gclient->addr,
			.flags = 1,
			.len = 2,
			.buf = (__u8*)&data,
		},
	};
		rec = i2c_transfer(gclient->adapter,r_msg,ARRAY_SIZE(r_msg));
		if(rec != ARRAY_SIZE(r_msg))
		{
			printk("i2c_transfer is error\n");
			return -1;
		}
		data = data >> 8 | data << 8;
		return data;
}

int si7006_probe(struct i2c_client* client, const struct i2c_device_id* id)
{

	unsigned short data;
    printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);
	gclient = client;
		
	data = i2c_hum_tmp(TMP_ADDR);
	printk("%d\n",data);
	data = i2c_hum_tmp(HUM_ADDR);
	printk("%d\n",data);

	
	
	return 0;
}
int si7006_remove(struct i2c_client* client)
{
    printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);
    return 0;
}

const struct of_device_id i2c_oftable[] = {
    { .compatible = "hqyj,si7006",},
    { }
};

struct i2c_driver si7006 = {
    .probe = si7006_probe,
    .remove = si7006_remove,
    .driver = {
        .name = "si7006_1",
        .of_match_table = i2c_oftable,
    }
};



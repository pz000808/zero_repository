#include "headdev.h"
/*
   myming{                                                                                    
 92         ming = <&gpiob 6 0>; 
 93     };
 94 

 
 */

struct device_node *mfnode;
struct gpio_desc *mfdesc;

void ming_init(void)
{
	mfnode = of_find_node_by_path("/myming");
	if(NULL == mfnode)
	{
		printk("get mfnode error\n");
		return;
	}
	mfdesc = gpiod_get_from_of_node(mfnode,"ming",0,GPIOD_OUT_LOW,NULL);
	if(IS_ERR(mfdesc))
	{
		printk("get mfnode node error\n");
		return ;
	}
}

void ming_del(void)
{
	gpiod_put(mfdesc);
}
void ming_set(void)
{
	gpiod_set_value(mfdesc,1);
}
void ming_des(void)
{
	gpiod_set_value(mfdesc,0);
}

#include "headdev.h"

struct class* cls = NULL;
struct device* dev = NULL;
int major,minor = 0;

int mycdev_open(struct inode *inode, struct file *file_accessed)
{
	printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);
	return 0;
}
long mycdev_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
	int data,rec,i;
	short sdata;
	i=0;
	switch(cmd)
	{
	case GET_HUM:
		data = i2c_hum_tmp(HUM_ADDR);	
		rec = copy_to_user((void*)arg,&data,GET_CMD_SIZE(GET_HUM));
		if(rec)
		{
			printk("copy_to_user hum error");
			return -1;
		}
		break;
	case GET_TMP:
		data = i2c_hum_tmp(TMP_ADDR);	
		rec = copy_to_user((void*)arg,&data,GET_CMD_SIZE(GET_TMP));
		if(rec)
		{
			printk("copy_to_user tmp error");
			return -1;
		}
		break;
	case LED1_ON:
		led_set(1);
		break;
	case LED1_OFF:
		led_des(1);
		break;
	case LED2_ON:
		led_set(2);
		break;
	case LED2_OFF:
		led_des(2);
		break;
	case LED3_ON:
		led_set(3);
		break;
	case LED3_OFF:
		led_des(3);
		break;
	case FENG_ON:
		feng_set();
		break;
	case FENG_OFF:
		feng_des();
		break;
	case MOTU_ON:
		motor_set();
		break;
	case MOTU_OFF:
		motor_des();
		break;
	case MING_ON:
		ming_set();
		break;
	case MING_OFF:
		ming_des();
		break;
	case SET_T:
		rec=copy_from_user(&sdata,(void*)arg,GET_CMD_SIZE(cmd));
		if(rec)
		{
			printk("copy_from_user sdata error\n");
			return -1;
		}
		set_yu(sdata);
		break;		
	case GET_T:
		break;
	case SER_TMP:
		sart_yu();
		break;
	case SPI_TMP:
		rec =copy_from_user(&data,(void *)arg,GET_CMD_SIZE(cmd));
		if(rec)
		{
			printk("copy_from_user data error\n");
			return -1;
		}
		printk("kernal :data= %d\n",data);	
		set_spi(data,i);
		break;

	}
	return 0;
}
int mycdev_close(struct inode *inode, struct file *file)
{
	printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);
	return 0;
}

struct file_operations fops ={
	.open = mycdev_open,
	.unlocked_ioctl = mycdev_ioctl,
	.release = mycdev_close,
};

int creat_dev(void)
{
	int rec;
	major = register_chrdev(0,CNAME,&fops);
	if(major < 0)
	{
		printk("register char device error\n");
		return -1;
	}

	cls = class_create(THIS_MODULE,CNAME);
	if(IS_ERR(cls))
	{
		printk("class_create is error\n");
		rec =  PTR_ERR(cls);
		goto ERR1;
	}

	dev = device_create(cls,NULL,MKDEV(major,minor),NULL,CNAME);
	if(IS_ERR(dev))
	{
		printk("device_create is error\n");
		rec =  PTR_ERR(dev);
		goto ERR2;
	}
	printk("creat_dev successed \n");

	return 0;
ERR2:
	class_destroy(cls);

ERR1:
	unregister_chrdev(major,CNAME);

	return rec;

}

void des_dev(void)
{
	device_destroy(cls,MKDEV(major,0));
	class_destroy(cls);
	unregister_chrdev(major,CNAME);

}



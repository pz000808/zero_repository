#include "headdev.h"
/*
   myfeng{                                                                                    
 92         feng = <&gpioe 9 0>; 
 93     };
 94 

 
 */

struct device_node *fnnode;
struct gpio_desc *fdesc;

void feng_init(void)
{
	fnnode = of_find_node_by_path("/myfeng");
	if(NULL == fnnode)
	{
		printk("get fnnode error\n");
		return;
	}
	fdesc = gpiod_get_from_of_node(fnnode,"feng",0,GPIOD_OUT_LOW,NULL);
	if(IS_ERR(fdesc))
	{
		printk("get feng node error\n");
		return ;
	}
}

void feng_del(void)
{
	gpiod_put(fdesc);
}
void feng_set(void)
{
	gpiod_set_value(fdesc,1);
}
void feng_des(void)
{
	gpiod_set_value(fdesc,0);
}

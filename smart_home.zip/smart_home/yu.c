#include "headdev.h" 

short yu=28661;

void set_yu(short data)
{
	yu=data;
	printk("yu:%d\n",yu);
}

void sart_yu(void)
{
		short temp;
		temp = i2c_hum_tmp(TMP_ADDR);
//		printk("kernal :yu:temp:%d\n",temp);
		if(temp >yu)
		{
			feng_set();
			ming_set();
			return;
		}
}

#include <stdio.h>

int main(int argc, const char *argv[])
{
	float a = 30;
	short b;
	b = (short)((a+46.85)*65536/175.72)/1;
	printf("%d\n",b);
	return 0;
}


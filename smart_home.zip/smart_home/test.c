#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include "test.h"

void get_hum(int fd);
void get_tmp(int fd);
int set_led(int fd);
int set_motor(int fd);
int set_ming(int fd);
int set_feng(int fd);
int set_data(int fd);
int creat_hum(int fd);


int main(int argc, const char *argv[])
{
	int fd,chose;
	fd = open("./dev/mycdev",O_RDWR);
	if(fd < 0)
	{
		printf("open dev/mydev error \n");
		return -1;
	}
	while(1)
	{
		printf("***************************************\n");
		printf("1:读取湿度　2:读取温度　3:led灯控制　4:风扇控制 \n");
		printf("5:马达控制　6:蜂鸣器控制　7:设置温度阈值 8监控 9:退出\n");
		printf("***************************************\n");
		scanf("%d",&chose);
		while(getchar() != 10);
		switch(chose)
		{
		case 1:
			get_hum(fd);
			break;
		case 2:
			get_tmp(fd);
			break;
		case 3:
			set_led(fd);
			break;
		case 4:
			set_feng(fd);
			break;
		case 5:
			set_motor(fd);
			break;
		case 6:
			set_ming(fd);
			break;
		case 7:
			set_data(fd);
			break;
		case 8:
			creat_hum(fd);
			break;
		case 9:
			return 0;
			break;
		default:printf("请输入有效数字\n");
		}


	}

	return 0;
}
void get_hum(int fd)
{
	int hum;
	float rhum;
	ioctl(fd,GET_HUM,&hum);

	rhum = 125*hum/65536-6;
	printf("hum= %.2f\n",rhum);

}
void get_tmp(int fd)
{
	int tmp,data;
	float rtmp;
	ioctl(fd,GET_TMP,&tmp);
	rtmp = 175.72*tmp/65536-46.85;
	data = (int)(rtmp*100/1);
	printf("data = %d\n",data);
	ioctl(fd,SPI_TMP,&data);
	printf("tmp= %.2f\n",rtmp);
}
int set_led(int fd)
{
	int chose,status;
	while(1)
	{
		printf("请输入要操作的灯：1:LED1  2:LED2 3:LED3 4:退出\n");
		scanf("%d",&chose);
		while(getchar() != 10);
		switch(chose)
		{
		case 1:
			printf("1:亮　2:灭\n");
			scanf("%d",&status);
			while(getchar() != 10);
			if(1 == status)
				ioctl(fd,LED1_ON,&status);
			else
				ioctl(fd,LED1_OFF,&status);
			break;
		case 2:
			printf("1:亮　2:灭\n");
			scanf("%d",&status);
			while(getchar() != 10);
			if(1 == status)
				ioctl(fd,LED2_ON,&status);
			else
				ioctl(fd,LED2_OFF,&status);
			break;
		case 3:
			printf("1:亮　2:灭\n");
			scanf("%d",&status);
			while(getchar() != 10);
			if(1 == status)
				ioctl(fd,LED3_ON,&status);
			else
				ioctl(fd,LED3_OFF,&status);
			break;
		case 4:
			return 0;
			break;
		default:printf("请输入有效数字\n");
		}
	}
	return 0;
}

int set_motor(int fd)
{
	int chose;
	while(1)
	{
		printf("１打开马达   ２关闭马达　３退出\n");
		scanf("%d",&chose);
		while(getchar() != 10);
		switch(chose)
		{
		case 1:
			ioctl(fd,MOTU_ON,&chose);
			break;
		case 2:
			ioctl(fd,MOTU_OFF,&chose);
			break;
		case 3:
			return 0;
		default:printf("输入错误\n");
		}
	}
}
int set_feng(int fd)
{
	int chose;
	while(1)
	{
		printf("１打开风扇   ２关闭风扇 3退出\n");
		scanf("%d",&chose);
		while(getchar() != 10);
		switch(chose)
		{
		case 1:
			ioctl(fd,FENG_ON,&chose);
			break;
		case 2:
			ioctl(fd,FENG_OFF,&chose);
			break;
		case 3:
			return 0;
		default:printf("输入错误\n");
		}
	}
}
int set_ming(int fd)
{
	int chose;
	while(1)
	{
		printf("１打开蜂鸣器   ２关闭蜂鸣器 3退出\n");
		scanf("%d",&chose);
		while(getchar() != 10);
		switch(chose)
		{
		case 1:
			ioctl(fd,MING_ON,&chose);
			break;
		case 2:
			ioctl(fd,MING_OFF,&chose);
			break;
		case 3:
			return 0;
		default:printf("输入错误\n");
		}
	}
}
int set_data(int fd)
{
	short data;
	float a;
	scanf("%f",&a);
	while(getchar() != 10);
	data = (short)((a+46.85)*65536/175.72)/1;
	ioctl(fd,SET_T,&data);
	return 0;

}

int creat_hum(int fd)
{
	int pid;
	pid = fork();
	if(pid<0) 
	{
		return 0;
	}
	if(pid == 0)
	{
		while(1)
		{
			ioctl(fd,SER_TMP,&pid);
			sleep(1);
		}

	}
}

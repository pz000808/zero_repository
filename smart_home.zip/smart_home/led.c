#include "headdev.h"
/*
   myleds{                                                                                                                                                                         
   67         compatible = "hqyj,leds";
   68         core_leds{
   69             led1 = <&gpioz 5 0>;
   70             led2 = <&gpioz 6 0>;
   71             led3 = <&gpioz 7 0>;
   72         };
   73         extend_leds{
   74             led1 = <&gpioe 10 0>;
   75             led2 = <&gpiof 10 0>;
   76             led3 = <&gpioe 8  0>;
   77         };
   78     };
 */
struct device_node *lednode;
struct gpio_desc *desc[3];

int led_register(void)
{
	int rec = 0;
	lednode = of_find_node_by_path("/myleds/extend_leds");
	if(NULL == lednode)
	{
		printk("get led node error\n");
		return -1;
	}
	desc[0] = gpiod_get_from_of_node(lednode,"led1",0,GPIOD_OUT_HIGH,NULL);
	if(IS_ERR(desc[0]))
	{
		printk("get led1 node error\n");
		rec = PTR_ERR(desc[0]);
		return rec;
	}
	desc[1] = gpiod_get_from_of_node(lednode,"led2",0,GPIOD_OUT_HIGH,NULL);
	if(IS_ERR(desc[1]))
	{
		printk("get led2 node error\n");
		rec = PTR_ERR(desc[1]);
		 goto ERR1;
	}
	desc[2] = gpiod_get_from_of_node(lednode,"led3",0,GPIOD_OUT_HIGH,NULL);
	if(IS_ERR(desc[2]))
	{
		printk("get led3 node error\n");
		rec = PTR_ERR(desc[3]);	
		goto ERR2;
	}
	
	return 0;
	desc[0] = gpiod_get_from_of_node(lednode,"led1",0,GPIOD_OUT_HIGH,NULL);
	if(IS_ERR(desc[0]))
	{
		printk("get led1 node error\n");
		rec = PTR_ERR(desc[0]);
		return rec;
	}

ERR2:
	gpiod_put(desc[1]);
ERR1:
	gpiod_put(desc[0]);
	return rec;
}
void led_unregister(void)
{
//	int i;
/*	for(i=1;i<4;i++)
	{
		led_des(i);
	}
*/	gpiod_put(desc[0]);
	gpiod_put(desc[1]);
	gpiod_put(desc[2]);
}

void led_set(int nled)
{
	gpiod_set_value(desc[nled-1],1);	
}
void led_des(int nled)
{
	gpiod_set_value(desc[nled-1],0);
}


#include "headdev.h"

/*
     mydev{
 85         interrupt-parent = <&gpiof>;
 86         interrupts = <9 0>,<7 0>,<8 0>;
 87         keys      = <&gpiof 9 0>,<&gpiof 7 0>,<&gpiof 8 0>;
 88         led = <&gpioe 10 0>,<&gpiof 10 0>,<&gpioe 8 0>;
 89     };

*/
int count=0;
struct device_node *irq_node = NULL;
unsigned int irq;
extern struct gpio_desc *desc[3];
struct timer_list spitimer;


void spitimer_handle(struct timer_list *timer)
{
	if(count==0)
		return;
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	gpiod_set_value(desc[0],!gpiod_get_value(desc[0]));
	gpiod_set_value(desc[1],!gpiod_get_value(desc[1]));
	gpiod_set_value(desc[2],!gpiod_get_value(desc[2]));
	printk("irq:count = %d\n",count);
}
void des_spitimer(void)
{
	 del_timer(&spitimer);
}
int reg_spitimer(void)
{
	spitimer.expires = jiffies+1;
	timer_setup(&spitimer,spitimer_handle,0);
	add_timer(&spitimer);
	return 0;
}

irqreturn_t my_irq_handle(int irqno,void *dev)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	count++;
	mod_timer(&spitimer,jiffies+1);
	return IRQ_HANDLED;
}

int reg_irq(void)
{
	int rec;
	irq_node = of_find_node_by_path("/mydev");
	if(irq_node == NULL)
	{
		printk("get irq_node error\n");
		return -1;
	}
	irq = irq_of_parse_and_map(irq_node,0);
	if(!irq)
	{
		printk("get irq error\n");
		return -1;
	}
	rec = request_irq(irq,my_irq_handle,IRQF_TRIGGER_FALLING,"myirqs",NULL);
	if(rec)
	{
		printk("request_irq is error\n");
		return rec;
	}
	reg_spitimer();	
	return 0;
}

void irq_free(void)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	gpiod_set_value(desc[0],!gpiod_get_value(desc[0]));
	gpiod_set_value(desc[1],!gpiod_get_value(desc[1]));
	gpiod_set_value(desc[2],!gpiod_get_value(desc[2]));
	des_spitimer();
	free_irq(irq,NULL);
}





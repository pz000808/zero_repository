#ifndef __HEADDEV_H__
#define __HEADDEV_H__

#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/io.h>
#include <linux/uaccess.h>
#include <linux/device.h>
#include <linux/i2c.h>
#include <linux/of.h>
#include <linux/of_gpio.h>
#include <linux/gpio.h>
#include <linux/spi/spi.h>
#include <linux/of_irq.h>
#include <linux/interrupt.h>
#include <linux/timer.h>

#define CNAME  "mycdev"
#define GET_CMD_SIZE(cmd)  ((cmd>>16)&0x3fff)


#define GET_TMP _IOR('H',0,int) //读取温度
#define GET_HUM _IOR('H',1,int) //读取湿度
#define LED1_ON  _IOW('L',1,int) //LED亮
#define LED1_OFF  _IOW('L',0,int) //LED灭
#define LED2_ON  _IOW('E',1,int) //LED亮
#define LED2_OFF  _IOW('E',0,int) //LED灭
#define LED3_ON  _IOW('D',1,int) //LED亮
#define LED3_OFF  _IOW('D',0,int) //LED灭
#define FENG_ON  _IOW('F',1,int)
#define FENG_OFF  _IOW('F',0,int)
#define MOTU_ON  _IOW('M',1,int)
#define MOTU_OFF  _IOW('M',0,int)
#define MING_ON _IOW('G',1,int)
#define MING_OFF _IOW('G',0,int)
#define SET_T    _IOW('S',0,short)
#define GET_T    _IOR('S',0,int)
#define SPI_TMP    _IOW('s',0,int)
#define SER_TMP    _IOW('R',0,int)




#define TMP_ADDR 0xe3 //获取湿度命令码
#define HUM_ADDR 0xe5 //获取湿度命令码


void set_yu(short data);
void sart_yu(void);
int creat_dev(void); //创建字符备驱动
void des_dev(void); //销毁设备驱动
int i2c_hum_tmp(unsigned char reg); //获取温、湿度
int set_spi(int data,int i);

int led_register(void); //led初始化
void led_unregister(void);//注销led gpio子系统
void led_set(int nled); //led亮
void led_des(int nled); //led灭
int reg_irq(void);//申请中断子系统
void irq_free(void);//释放中断子系统
int reg_mytimer(void);

void mytimer_handle(struct timer_list *timer);
void mod_mytimer(void);
void des_mytimer(void);

void motor_init(void);
void motor_del(void);
void motor_set(void);
void motor_des(void);

void feng_init(void);
void feng_del(void);
void feng_set(void);
void feng_des(void);

void ming_init(void);
void ming_del(void);
void ming_set(void);
void ming_des(void);

#endif

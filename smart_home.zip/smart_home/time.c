#include "headdev.h"

struct timer_list mytimer; 

void mytimer_handle(struct timer_list *timer)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
}

void mod_mytimer(void)
{
	mod_timer(&mytimer,jiffies+HZ);
}

void des_mytimer(void)
{
	 del_timer(&mytimer);
}
int reg_mytimer(void)
{
	mytimer.expires = jiffies+1;
	timer_setup(&mytimer,mytimer_handle,0);
	add_timer(&mytimer);
	return 0;
}

#include "headdev.h"

extern struct i2c_driver si7006;
extern struct spi_driver m74hc595;

static int __init demo_init(void)
{
	int rec;

	rec = creat_dev();//注册字符设备
	if(rec)
	{
		printk("creat_dev error\n");
		return -1;
	}
	i2c_add_driver(&si7006);//注册iic 
	led_register(); //led初始化
	spi_register_driver(&m74hc595); //注册spi
	reg_irq();
	reg_mytimer();
	motor_init();
	feng_init();
	ming_init();
	return 0;
}

static void __exit demo_exit(void)
{
	motor_del();
	feng_del();
	ming_del();
	 des_mytimer();
	irq_free();
	spi_unregister_driver(&m74hc595);//注销spi
	led_unregister();//注销led gpio子系统
	i2c_del_driver(&si7006);//注销iic
	des_dev();//注销字符设备
}

module_init(demo_init);
module_exit(demo_exit);
MODULE_LICENSE("GPL");

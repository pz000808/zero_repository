#include "headdev.h"
/*
   mymotor{                                                                                    
 92         motor = <&gpiof 6 0>; 
 93     };
 94 

 
 */

struct device_node *monode;
struct gpio_desc *mdesc;

void motor_init(void)
{
	monode = of_find_node_by_path("/mymotor");
	if(NULL == monode)
	{
		printk("get monode error\n");
		return;
	}
	mdesc = gpiod_get_from_of_node(monode,"motor",0,GPIOD_OUT_LOW,NULL);
	if(IS_ERR(mdesc))
	{
		printk("get motor node error\n");
		return ;
	}
}

void motor_del(void)
{
	gpiod_put(mdesc);
}
void motor_set(void)
{
	gpiod_set_value(mdesc,1);
}
void motor_des(void)
{
	gpiod_set_value(mdesc,0);
}

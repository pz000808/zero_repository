#ifndef __MENU_H__
#define __MENU_H__

#define trace()/*printf("FILE : %s func : %s line : %d\n", __FILE__, __func__, __LINE__)*/ ;

void main_menu(void);

void register_menu(void);

void menu_login(void);

void login_operation_menu(void);

void modify_menu(void);

void worker_menu(void);

#endif
